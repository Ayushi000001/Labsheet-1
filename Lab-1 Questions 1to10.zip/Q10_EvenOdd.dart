void main() {
  int n = 24;
  if (n % 2 == 0) {
    print("Even");
  } else {
    print("Odd");
  }
}