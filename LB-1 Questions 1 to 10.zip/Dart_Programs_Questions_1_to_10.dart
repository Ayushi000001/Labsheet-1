// DART PROGRAMS - QUESTIONS 1 TO 10
// Simple and beginner-friendly codes

// 1. Display name, course, college name, and semester
void question1() {
  print("Name: Your Name");
  print("Course: BCA");
  print("College: COER University");
  print("Semester: Your Semester");
}


// 2. Declare variables of different data types
void question2() {
  int age = 21;
  double marks = 85.5;
  String name = "Ayushi";
  bool student = true;

  print(age);
  print(marks);
  print(name);
  print(student);
}


// 3. Demonstrate var, final, and const
void question3() {
  var name = "Ayushi";
  final age = 21;
  const pi = 3.14;

  print(name);
  print(age);
  print(pi);
}


// 4. Accept two numbers and display sum, difference, product, and quotient
import 'dart:io';

void question4() {
  print("Enter first number:");
  double a = double.parse(stdin.readLineSync()!);

  print("Enter second number:");
  double b = double.parse(stdin.readLineSync()!);

  print("Sum = ${a + b}");
  print("Difference = ${a - b}");
  print("Product = ${a * b}");
  print("Quotient = ${a / b}");
}


// 5. Calculate area and perimeter of a rectangle
void question5() {
  double length = 10;
  double width = 5;

  print("Area = ${length * width}");
  print("Perimeter = ${2 * (length + width)}");
}


// 6. Calculate area of a circle
void question6() {
  double radius = 5;
  double area = 3.14 * radius * radius;

  print("Area of Circle = $area");
}


// 7. Convert Celsius to Fahrenheit
void question7() {
  double celsius = 25;
  double fahrenheit = (celsius * 9 / 5) + 32;

  print("Fahrenheit = $fahrenheit");
}


// 8. Swap values of two variables
void question8() {
  int a = 10;
  int b = 20;

  print("Before swap: a = $a, b = $b");

  int temp = a;
  a = b;
  b = temp;

  print("After swap: a = $a, b = $b");
}


// 9. Check whether a number is positive, negative, or zero
void question9() {
  int n = -5;

  if (n > 0) {
    print("Positive");
  } else if (n < 0) {
    print("Negative");
  } else {
    print("Zero");
  }
}


// 10. Check whether a number is even or odd
void question10() {
  int n = 24;

  if (n % 2 == 0) {
    print("Even");
  } else {
    print("Odd");
  }
}
